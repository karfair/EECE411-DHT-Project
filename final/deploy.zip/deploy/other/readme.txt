# PlanetlabDeployProgram

A program for deploying file to planet lab servers

1. Run ssh filter out broken ssh server

2. Run run.py to deploy
