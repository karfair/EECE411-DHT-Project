import os
import random
import time

with open("nodes.txt") as f:
	nodeList = f.readlines()
nodeList = [x.strip('\n') for x in nodeList]
nodeList = [x.strip('\r') for x in nodeList]
print nodeList;

while True:
	print "Options:\n  deploy - transfer file \n  init - install Java on Remote machine\n  on - Turn on monitor programs\n  off - turn off all monitor programs\n  refresh - refresh the node list\n  list - list all nodes\n  clear - clear screen\n  quit - quit deploy program\n"
	command = raw_input('Enter command: ')


	if command == "deploy":
		fname = "group2.jar"
		for i in range(0 , len(nodeList)):
			os.system("scp "+ fname +" ubc_eece411_1@"+nodeList[i]+":"+ fname+" &")
	elif command == "init":
		for i in range(0 , len(nodeList)):
			os.system("ssh ubc_eece411_1@"+nodeList[i]+" wget -O jre.rpm http://javadl.sun.com/webapps/download/AutoDL?BundleId=101397")
			os.system("ssh ubc_eece411_1@"+nodeList[i]+" sudo rpm -ivh jre.rpm &")
	elif command == "on": 
		center = raw_input('Enter centralized server address or no: \n')
		port = raw_input('Select the port you want to use: \n')
		if center=="no":
			for i in range(0 , len(nodeList)):
				# print "ssh ubc_eece411_1@"+nodeList[i]+" java -cp a2.jar com.group2.eece411.Server sc " + port + " " +nodeList[int(random.random()*len(nodeList))] +" &"
				os.system("ssh ubc_eece411_1@"+nodeList[i]+" java -cp a2.jar com.group2.eece411.Server sc " + port + " " +nodeList[int(random.random()*len(nodeList))] +" & disown")
		else:
			for i in range(0 , len(nodeList)):
				# print "ssh ubc_eece411_1@"+nodeList[i]+" java -cp a2.jar com.group2.eece411.Server sc " + port+ " " + center +" &"
				os.system("ssh ubc_eece411_1@"+nodeList[i]+" java -cp a2.jar com.group2.eece411.Server sc " + port+ " " + center +" & disown")
	elif command == "off":
		for i in range(0 , len(nodeList)):
			os.system("ssh ubc_eece411_1@"+nodeList[i]+" killall java &")
	elif command == "refresh":
		with open("nodes.txt") as f:
			nodeList = f.readlines()
		nodeList = [x.strip('\n') for x in nodeList]
	elif command == "list":
		for i in range(0 , len(nodeList)):
			print nodeList[i]
	elif command == "clear": 
		os.system("clear")
	elif command == "quit": 
		quit()
	elif command == "go":
		for i in range(0 , len(nodeList)):
			print str(i) + "/" + str(len(nodeList)) + " " + nodeList[i]+":"
			if i == 0:
				os.system("ssh ubc_eece411_1@"+nodeList[i]+" 'java -Xmx64m -cp group2.jar com.Server' &")
				time.sleep(5)
			else:
				os.system("ssh ubc_eece411_1@"+nodeList[i]+" 'java -Xmx64m -cp group2.jar com.Server plonk.cs.uwaterloo.ca > group2_log.txt 2>&1' &")
				time.sleep(5)
	else:
		pass
