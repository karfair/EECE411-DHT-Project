import os
import random
import time
import paramiko


menu = ["transfer - transfer file",
		"download - download Java on Remote machine",
		"install - install Java on Remote machine",
		"on - Turn on monitor programs",
		"off - turn off all monitor programs",
		"refresh - refresh the node list",
		"cron - start cron jobs",
		"silence - Enter command and discard output",
		"clear - clear screen",
		"q - quit deploy program",
		]
# miss = [62,63,70,124]

with open("ssh-able.txt") as f:
	nodeList = f.readlines()
nodeList = [x.strip('\n') for x in nodeList]
nodeList = [x.strip('\r') for x in nodeList]
print nodeList;

ssh=paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
while True:
	print "\nOptions:"
	for i in xrange(0,len(menu)):
		print menu[i]

	command = raw_input('Enter command: ')

	if command == "transfer":
		fname = raw_input('Enter the name of the file you want to transfer\n')
		for i in range(0 , len(nodeList)):
			os.system("scp "+ fname +" ubc_eece411_1@"+nodeList[i]+":"+ fname+" >/dev/null  2>&1 &")
		pass
	elif command == "download":
		command = "wget -O jre.rpm http://javadl.sun.com/webapps/download/AutoDL?BundleId=101397 &"
	elif command == "install":
			command ="sudo rpm -ivh jre.rpm"
	elif command == "on": 
		center = raw_input('Enter centralized server address or no: \n')
		port = raw_input('Select the port you want to use: \n')
		for i in range(0 , 110):
			print i
			try:
				ssh.connect(nodeList[i], username="ubc_eece411_1", key_filename="home_rsa.pub")
				stdin, stdout, stderr = ssh.exec_command(command) # !!! command!!!
				# for line in stdout:
				# 	print line.strip('\n')
				ssh.close()
				print "success"
			except:
				print "fail"
		for i in range(111 , 119):
			#111, 114, 117
			print i
			try:
				ssh.connect(nodeList[i], username="ubc_eece411_1", key_filename="home_rsa.pub")
				stdin, stdout, stderr = ssh.exec_command(command) # !!! command!!!
				# for line in stdout:
				# 	print line.strip('\n')
				ssh.close()
				print "success"
			except:
				print "fail"
		pass
	elif command == "off":
		command = "killall java"
	elif command == "refresh":
		with open("ssh-able.txt") as f:
			nodeList = f.readlines()
		nodeList = [x.strip('\n') for x in nodeList]
	elif command == "cron": 
		command = " crontab cron.txt"
	elif command == "clear": 
		os.system("clear")
		pass
	elif command == "q": 
		quit()
	elif command == "ls": 
		#custom command
		command = "ls"
	elif command == "r": 
		#custom command
		command = "java -version"
	else:
		pass

	# j = 0
	# count = 0
	for i in range(0 , len(nodeList)):
	# i = 0
	# if i ==0 :
		print "{0:4d}	{1}:".format(i+1, nodeList[i])
		try:
			ssh.connect(nodeList[i], username="ubc_eece411_1", key_filename="home_rsa.pub")
			if(command == "transfer"):
				# sftp = ssh.open_sftp()
				scp = SCPClient(ssh.get_transport())
				# sftp.put("~/"+fname, "~/"+fname)
				scp.put("~/java.txt", "~/java.txt")
			else:
				stdin, stdout, stderr = ssh.exec_command(command)
			for line in stdout:
				print line.strip('\n')
			for line in stderr:
				print line.strip('\n')
			ssh.close()
			# count = count + 1
			# print "success"
		except:
			print "fail"
