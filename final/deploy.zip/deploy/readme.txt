deploy.py is used to deploy the .jar file to PlanetLab nodes, run it, and also shut it down.

Files inside the other folder were used to weed out bad PlanetLab nodes via Ping/SSH and were 
also used to install jre on all the machines.