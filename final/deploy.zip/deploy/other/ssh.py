import os
import random
import time
import paramiko
# import ssh

# with open("brokennodes.txt") as f:
# with open("workingnodes.txt") as f:
with open("nodes.txt") as f:
	nodeList = f.readlines()
nodeList = [x.strip('\n') for x in nodeList]
nodeList = [x.strip('\r') for x in nodeList]
print nodeList;

file = open("ssh-able.txt", "w")
broken = open("ssh-broken.txt", "w")

# for i in range(0 , len(nodeList)):
# 	response = os.system("ssh -q -o ConnectTimeout=5 ubc_eece411_1@" + nodeList[i] +" exit")
# 	print response

# response = os.system("ssh -q ubc_eece411_1@" + nodeList[0] +" exit")
# print response

ssh=paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
count=len(nodeList)
for i in range(0 , count):
	# print(i/count, end='/r')
	try:
		ssh.connect(nodeList[i], username="ubc_eece411_1", key_filename="home_rsa.pub", timeout=0.2)
		print "{0:4d} success	{1}".format(i, nodeList[i])
		# stdin, stdout, stderr = ssh.exec_command('ls')
		# for line in stdout:
		# 	print '... ' + line.strip('\n')
		ssh.close()
		file.write(nodeList[i] + "\n")
	except:
		print "{0:4d} fails	{1}".format(i, nodeList[i])
		broken.write(nodeList[i] + "\n")

file.close()
broken.close()